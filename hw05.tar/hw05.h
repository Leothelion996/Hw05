/***********************************************************
∗ Leonardo Herrera ∗ CS1B TTh 7:30 − 9:40pm ∗ Assignemnt 1 ∗
∗ hw05 ∗ Due : Sunday , March 17 , 2024                    ∗
************************************************************/

#ifndef _H_
#define _H_

/***********************************************************
 * This assigment is for debugging the code provided to us 
 * by the professor.                                       *
 ***********************************************************/

#include <iostream>

#endif